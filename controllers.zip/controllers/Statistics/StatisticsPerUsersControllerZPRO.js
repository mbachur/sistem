'use strict';
const _0x14b200 = _0x2bf8;
(function (_0x3e8603, _0x3c2173) {
    const _0x1c81db = _0x2bf8, _0x2a14ed = _0x3e8603();
    while (!![]) {
        try {
            const _0x56ae9a = -parseInt(_0x1c81db(0x136)) / (0x1 * -0x4b + 0x17 * -0x128 + 0x1ae4) * (-parseInt(_0x1c81db(0x140)) / (-0x11f * -0x16 + 0x11 * 0xe9 + 0x1 * -0x2821)) + -parseInt(_0x1c81db(0x14d)) / (0x256d + 0x269 * 0xf + -0x4991) + parseInt(_0x1c81db(0x14c)) / (-0x1 * 0x1261 + -0x1615 + 0x143d * 0x2) + parseInt(_0x1c81db(0x124)) / (-0x1 * 0x1c13 + -0x81 * 0x35 + 0x36cd * 0x1) + -parseInt(_0x1c81db(0x13f)) / (-0x1f * 0x61 + -0x251e + 0x30e3) + parseInt(_0x1c81db(0x152)) / (0x23e2 * -0x1 + 0x71b + 0x1cce) * (-parseInt(_0x1c81db(0x134)) / (0xe57 * -0x1 + -0x94 * 0x4 + 0x10af)) + -parseInt(_0x1c81db(0x130)) / (-0xbbf * 0x3 + -0x4 * 0x829 + 0x43ea);
            if (_0x56ae9a === _0x3c2173)
                break;
            else
                _0x2a14ed['push'](_0x2a14ed['shift']());
        } catch (_0x39b006) {
            _0x2a14ed['push'](_0x2a14ed['shift']());
        }
    }
}(_0x3c84, 0xc26a + 0xf0c5 * 0x2 + 0x23dc5 * 0x1));
function _0x3c84() {
    const _0xffbe87 = [
        '635268PhFmAr',
        '699878pUJsXK',
        '__awaiter',
        'ices/Stati',
        'FCtnG',
        'CVNNs',
        'json',
        'tenantId',
        'value',
        'dloEx',
        'impdw',
        'YcmJo',
        '__esModule',
        '318900pJQjQw',
        '113037vagKWv',
        'throw',
        'gwBCf',
        'apply',
        '__importDe',
        '7014qMvsLD',
        'query',
        '1711145RUTUFQ',
        'user',
        'next',
        'ttgjy',
        'KHdMD',
        'Rxsaq',
        'done',
        'LCdIF',
        'default',
        'lHEWM',
        'isticsPerU',
        'fault',
        '764649vpwxsF',
        '../../serv',
        'erty',
        'demDo',
        '1784crdhdV',
        'ZLArG',
        '1UUalwq',
        'stics/Stat',
        'index',
        'defineProp',
        'endDate',
        'startDate',
        'JPwOk',
        'sersZPRO',
        'then'
    ];
    _0x3c84 = function () {
        return _0xffbe87;
    };
    return _0x3c84();
}
var __awaiter = this && this[_0x14b200(0x141)] || function (_0x4bfc28, _0x5627bb, _0x4c44ab, _0x4a8bec) {
        const _0x451435 = _0x14b200, _0x538019 = {
                'YcmJo': function (_0x2c00ff, _0x16e1af) {
                    return _0x2c00ff(_0x16e1af);
                },
                'lHEWM': function (_0xb2ec77, _0x26b7c3) {
                    return _0xb2ec77 instanceof _0x26b7c3;
                },
                'impdw': function (_0x2f5ec3, _0x13058c) {
                    return _0x2f5ec3(_0x13058c);
                },
                'Rxsaq': function (_0x48c8a2, _0x3aa329) {
                    return _0x48c8a2(_0x3aa329);
                },
                'gwBCf': function (_0x5180d6, _0x599d03) {
                    return _0x5180d6(_0x599d03);
                },
                'CVNNs': _0x451435(0x14e),
                'ttgjy': function (_0x50e3c5, _0x5c5d22) {
                    return _0x50e3c5(_0x5c5d22);
                },
                'KHdMD': function (_0x12fabd, _0x2b6a98) {
                    return _0x12fabd(_0x2b6a98);
                },
                'LCdIF': function (_0x5883e8, _0x2e9a66) {
                    return _0x5883e8(_0x2e9a66);
                }
            };
        function _0x2af6c4(_0x337d76) {
            const _0x120e7c = _0x451435, _0xa526c4 = {
                    'demDo': function (_0x517321, _0x16c40e) {
                        const _0x2594d7 = _0x2bf8;
                        return _0x538019[_0x2594d7(0x14a)](_0x517321, _0x16c40e);
                    }
                };
            return _0x538019[_0x120e7c(0x12d)](_0x337d76, _0x4c44ab) ? _0x337d76 : new _0x4c44ab(function (_0x313b3e) {
                const _0x13fd42 = _0x120e7c;
                _0xa526c4[_0x13fd42(0x133)](_0x313b3e, _0x337d76);
            });
        }
        return new (_0x4c44ab || (_0x4c44ab = Promise))(function (_0x24f9ed, _0x555cf6) {
            const _0x21eb57 = _0x451435, _0x35fbc1 = {
                    'JPwOk': function (_0x31185a, _0x36a25e) {
                        const _0x146409 = _0x2bf8;
                        return _0x538019[_0x146409(0x14f)](_0x31185a, _0x36a25e);
                    },
                    'dloEx': _0x538019[_0x21eb57(0x144)],
                    'FCtnG': function (_0xe0d1a1, _0x4d69b8) {
                        const _0x47fe99 = _0x21eb57;
                        return _0x538019[_0x47fe99(0x127)](_0xe0d1a1, _0x4d69b8);
                    },
                    'ZLArG': function (_0x5e28ae, _0x16f1fa) {
                        const _0x173b70 = _0x21eb57;
                        return _0x538019[_0x173b70(0x128)](_0x5e28ae, _0x16f1fa);
                    }
                };
            function _0x498bdd(_0x44bd7d) {
                const _0x470f62 = _0x21eb57;
                try {
                    _0x538019[_0x470f62(0x149)](_0x27907c, _0x4a8bec[_0x470f62(0x126)](_0x44bd7d));
                } catch (_0x3eb391) {
                    _0x538019[_0x470f62(0x129)](_0x555cf6, _0x3eb391);
                }
            }
            function _0x377d5a(_0xf93212) {
                const _0x12df21 = _0x21eb57;
                try {
                    _0x35fbc1[_0x12df21(0x13c)](_0x27907c, _0x4a8bec[_0x35fbc1[_0x12df21(0x148)]](_0xf93212));
                } catch (_0xe894d9) {
                    _0x35fbc1[_0x12df21(0x143)](_0x555cf6, _0xe894d9);
                }
            }
            function _0x27907c(_0x2700ac) {
                const _0x2fd637 = _0x21eb57;
                _0x2700ac[_0x2fd637(0x12a)] ? _0x35fbc1[_0x2fd637(0x135)](_0x24f9ed, _0x2700ac[_0x2fd637(0x147)]) : _0x35fbc1[_0x2fd637(0x143)](_0x2af6c4, _0x2700ac[_0x2fd637(0x147)])[_0x2fd637(0x13e)](_0x498bdd, _0x377d5a);
            }
            _0x538019[_0x21eb57(0x12b)](_0x27907c, (_0x4a8bec = _0x4a8bec[_0x21eb57(0x150)](_0x4bfc28, _0x5627bb || []))[_0x21eb57(0x126)]());
        });
    }, __importDefault = this && this[_0x14b200(0x151) + _0x14b200(0x12f)] || function (_0x33f969) {
        const _0x36e15c = _0x14b200;
        return _0x33f969 && _0x33f969[_0x36e15c(0x14b)] ? _0x33f969 : { 'default': _0x33f969 };
    };
const _0x4b02fb = {};
_0x4b02fb[_0x14b200(0x147)] = !![], Object[_0x14b200(0x139) + _0x14b200(0x132)](exports, _0x14b200(0x14b), _0x4b02fb), exports[_0x14b200(0x138)] = void (-0x1bbd + -0x12d5 + 0x2e92);
const StatisticsPerUsersZPRO_1 = __importDefault(require(_0x14b200(0x131) + _0x14b200(0x142) + _0x14b200(0x137) + _0x14b200(0x12e) + _0x14b200(0x13d))), index = (_0x528b34, _0x3f6dc6) => __awaiter(void (-0x165b + -0x2 * 0x61d + 0x2295), void (-0x3 * -0x107 + 0xc7d + 0x2 * -0x7c9), void (-0xcec * 0x2 + -0x3d * -0x62 + 0x27e), function* () {
        const _0x4da8e0 = _0x14b200, {tenantId: _0x26e87b} = _0x528b34[_0x4da8e0(0x125)], {
                startDate: _0x54a98c,
                endDate: _0x394cb0
            } = _0x528b34[_0x4da8e0(0x153)], _0x5907ba = {};
        _0x5907ba[_0x4da8e0(0x13b)] = _0x54a98c, _0x5907ba[_0x4da8e0(0x13a)] = _0x394cb0, _0x5907ba[_0x4da8e0(0x146)] = _0x26e87b;
        const _0x2884ab = yield (-0xfb9 + 0x2501 * 0x1 + -0x718 * 0x3, StatisticsPerUsersZPRO_1[_0x4da8e0(0x12c)])(_0x5907ba);
        return _0x3f6dc6[_0x4da8e0(0x145)](_0x2884ab);
    });
function _0x2bf8(_0xde2ecc, _0x34e0b3) {
    const _0x36be38 = _0x3c84();
    return _0x2bf8 = function (_0x503ff1, _0x26977e) {
        _0x503ff1 = _0x503ff1 - (-0x1 * 0x15fa + 0x4b6 + -0x1f * -0x98);
        let _0x1a904b = _0x36be38[_0x503ff1];
        return _0x1a904b;
    }, _0x2bf8(_0xde2ecc, _0x34e0b3);
}
exports[_0x14b200(0x138)] = index;